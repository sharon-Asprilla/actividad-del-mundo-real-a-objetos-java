package com.example;

public class Computador {

    private String marca;
    private String modelo;
    private int memoriaRam;
    private int almazenamento;
    private boolean encendido;  

    public void setMarca(String marca) { this.marca = marca; }
    public String getMarca() { return marca; }

    public void setmodelo(String modelo) { this.modelo = modelo; }
    public String getmodelo() { return modelo; }

    public void setmemoriaRam(int memoriaRam) { this.memoriaRam = memoriaRam; }
    public int getmemoriaRam() { return memoriaRam; }

    public void setalmazenamento(int almazenamento) { this.almazenamento = almazenamento; }
    public int getalmazenamento() { return almazenamento; }

    public void setencendido(boolean encendido) { this.encendido = encendido; }
    public boolean getencendido() { return encendido;

    
    



        


    



    }}